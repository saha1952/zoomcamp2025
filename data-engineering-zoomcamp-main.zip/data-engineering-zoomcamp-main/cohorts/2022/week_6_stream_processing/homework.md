## Week 6 Homework
[Form](https://forms.gle/mSzfpPCXskWCabeu5)

The homework is mostly theoretical. In the last question you have to provide working code link, please keep in mind that this
question is not scored.

Deadline: 14 March, 22:00 CET