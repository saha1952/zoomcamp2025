## Course Project

The goal of this project is to apply everything we learned
in this course and build an end-to-end data pipeline.

Remember that to pass the project, you must evaluate 3 peers. If you don't do that, your project can't be considered compelete.


### Submitting 

#### Project Cohort #2

Project:

* Form: https://forms.gle/JECXB9jYQ1vBXbsw6
* Deadline: 2 May, 22:00 CET

Peer reviewing:

* Peer review assignments: [link](https://docs.google.com/spreadsheets/d/e/2PACX-1vShnv8T4iY_5NA8h0nySIS8Wzr-DZGGigEikIW4ZMSi9HlvhaEB4RhwmepVIuIUGaQHS90r5iHR2YXV/pubhtml?gid=964123374&single=true)
* Form: https://forms.gle/Pb2fBwYLQ3GGFsaK6
* Deadline: 9 May, 22:00 CET


#### Project Cohort #1

Project:

* Form: https://forms.gle/6aeVcEVJipqR2BqC8
* Deadline: 4 April, 22:00 CET

Peer reviewing:

* Peer review assignments: [link](https://docs.google.com/spreadsheets/d/e/2PACX-1vShnv8T4iY_5NA8h0nySIS8Wzr-DZGGigEikIW4ZMSi9HlvhaEB4RhwmepVIuIUGaQHS90r5iHR2YXV/pubhtml)
* Form: https://forms.gle/AZ62bXMp4SGcVUmK7
* Deadline: 11 April, 22:00 CET

Project feedback: [link](https://docs.google.com/spreadsheets/d/e/2PACX-1vRcVCkO-jes5mbPAcikn9X_s2laJ1KhsO8aibHYQxxKqdCUYMVTEJLJQdM8C5aAUWKFl_0SJW4rme7H/pubhtml)
