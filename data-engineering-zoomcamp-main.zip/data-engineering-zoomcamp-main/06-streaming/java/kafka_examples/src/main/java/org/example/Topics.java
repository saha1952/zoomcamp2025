package org.example;

public class Topics {
    public static final String INPUT_RIDE_TOPIC = "rides";
    public static final String INPUT_RIDE_LOCATION_TOPIC = "rides_location";
    public static final String OUTPUT_TOPIC = "vendor_info";
}
